Put these two files in this folder:
  1. emotion-ferplus-8.onnx
  2. haarcascade_frontalface_default.xml
See the main guide for the download links.
